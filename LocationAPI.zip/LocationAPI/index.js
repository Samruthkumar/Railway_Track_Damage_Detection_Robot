const express =  require('express');

const app = express();

app.get("/",(req,res,next)=>{
    const data = {latitude:13.564805,longitude: 80.027639};
    res.json(data);
});
app.listen(3000);